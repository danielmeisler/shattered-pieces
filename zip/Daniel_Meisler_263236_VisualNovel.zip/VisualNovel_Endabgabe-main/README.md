# VisualNovel_Endabgabe

Daniel Meisler<br>
Visual Novel<br>
Sommersemester 2022<br>



Visual Novel: https://danielmeisler.github.io/VisualNovel_Endabgabe/game.html

Code: https://github.com/danielmeisler/VisualNovel_Endabgabe/tree/main/Source

Konzept: https://github.com/danielmeisler/VisualNovel_Endabgabe/blob/main/concept/VisualNovel_Konzept_Daniel_Meisler_263236.pdf

Baumdiagramm (Ist auch im Konzept enthalten, aber besser lesbar): https://github.com/danielmeisler/VisualNovel_Endabgabe/blob/main/concept/Baumdiagramm.png

Zip: https://github.com/danielmeisler/VisualNovel_Endabgabe/tree/main/zip